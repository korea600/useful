--------------------------------------------------------
--  ������ ������ - ������-12��-14-2016   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence TB1_LAZYNESS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TB1_LAZYNESS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_ANONYMITY_REPLY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_ANONYMITY_REPLY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_ANONYMITY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_ANONYMITY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_APPROVAL_COMMENT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_APPROVAL_COMMENT_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 26 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_APPROVAL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_APPROVAL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 843 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_BOARD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_BOARD_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_COMMUTE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_COMMUTE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 108 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_DEPTBOARD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_DEPTBOARD_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_FILE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_FILE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_MAIL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_MAIL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_NOTICE_REPLY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_NOTICE_REPLY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_NOTICE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_NOTICE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 23 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_RECIPIENT_NOTE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_RECIPIENT_NOTE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_REPLY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_REPLY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_RESERVATION_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_RESERVATION_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 36 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_ROOMMAKE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_ROOMMAKE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 18 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_SALARY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_SALARY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 24 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_SCHEDULE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_SCHEDULE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 94 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_SEND_NOTE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_SEND_NOTE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_SHARETASK_REPLY_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_SHARETASK_REPLY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 3 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_SHARETASK_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_SHARETASK_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 182 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_VOTE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_VOTE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TBL_VOTEDATE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "TBL_VOTEDATE_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
